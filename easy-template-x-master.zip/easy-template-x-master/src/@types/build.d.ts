/**
 * Version number of the `easy-template-x` library.
 */
const EASY_VERSION: string;
