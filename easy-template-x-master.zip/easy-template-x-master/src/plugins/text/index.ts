export * from './textPlugin';
